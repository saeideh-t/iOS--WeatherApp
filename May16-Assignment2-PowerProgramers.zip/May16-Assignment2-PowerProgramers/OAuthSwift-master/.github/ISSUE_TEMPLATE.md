

### Description:

### OAuth Provider? (Twitter, Github, ..):


### OAuth Version:
- [ ] Version 1
- [ ] Version 2

### OS (Please fill the version) :
- [x] iOS :
- [ ] OSX :
- [ ] TVOS :
- [ ] WatchOS  :

### Installation method:
- [ ] Carthage
- [ ] CocoaPods
- [ ] Manually

### Library version:
- [ ] head
- [ ] v1.2.1
- [ ] v1.2 (Swift 4.0)
- [ ] v1.0.0
- [ ] v0.6
- [ ] other: (Please fill in the version you are using.)

### Xcode version:
- [ ] 9.3 (Swift 4.1)
- [ ] 9.0 (Swift 4.0)
- [ ] 9.0 (Swift 3.2)
- [ ] 8.x (Swift 3.x)
- [ ] 8.0 (Swift 2.3)
- [ ] 7.3.1
- [ ] other: (Please fill in the version you are using.)

- [ ] objective c
