//
//  WTVController.swift
//  May16-Assignment2-PowerProgramers
//
//  Created by user151804 on 5/13/19.
//  Copyright © 2019 Seneca College. All rights reserved.
//
import UIKit




class WTVController: UITableViewController, FetchWeatherDelegate {
    
    
    @IBOutlet var forecastsTableView: UITableView!
    //    @IBOutlet var forecastsTableView: [UITableView]!
    
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var iconLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var wtextLabel: UILabel!
    var weatherGetter = FetchWeather()
    var weatherResult = NSDictionary()
    
    let wc = YWeatherAPI.YWeatherAPI.shared //weather call
    
    var passedLocation = "london,on"  //this will be passed by func prepare (segue from Saved City View)
    
    //variables needed for basic display
    //location, temp, code
    var locationStr:String?
    var tempStr:String?
    var wcodeStr:String?
    var wtextStr:String?
    var forecastsArray:NSMutableArray = []
//    //background serial Queue
//    let serialQueue = DispatchQueue(label: "getYahooWeatherData") //Not Needed used Protocol
//    let qGroup = DispatchGroup() //Not Needed Used Protocol
    
    
    func weatherDetailsResult(value: NSDictionary) {
        weatherResult = value
        updateLabels(result: value)
        let forecasts = self.weatherResult["forecasts"] as! NSArray
        
                forecasts.forEach{
                self.forecastsArray.add($0)
                                }
                //first entry is the current day  so we can remove it
                self.forecastsArray.removeObject(at: 0)
                DispatchQueue.main.async { [weak self] in
                    self?.tableView.reloadData()
                }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.forecastsArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "localDays", for: indexPath)
        
        
        //cell.textLabel?.text = "Row \(indexPath.row)"
        var dayDetails = self.forecastsArray.object(at: indexPath.row) as? Dictionary<String, Any>
        //print(dayDetails)
        cell.textLabel!.text = secsToDateStr(dayDetails?["date"] as? Int ?? 0,"E, MMM dd")
        let high = dayDetails?["high"] as! Int
        let low = dayDetails?["low"] as! Int
        let code = dayDetails?["code"] as! Int
        let wicon = self.wc.iconDict[code]!
        let hiLow = padLeft(str: String("\(high)/\(low)"), toLength: 10, withPad: " ")
        //cell.dateLabel.text = ""
        cell.detailTextLabel!.text = String("\(wicon)\(hiLow)")
        
        return cell
    }
    
    //leftPad strings
    func padLeft(str:String, toLength: Int,withPad:String) -> String {
        let toPad = toLength - str.count
        if toPad < 1 {
            return str
        }
        return "".padding(toLength: toPad, withPad: withPad, startingAt: 0) + str
    }
    //convert second (given by Yahoo) to date string
    func secsToDateStr(_ dateNum:Int, _ formatString:String = "yyyy-MM-dd HH:mm")->(String){
        //print("date published: \(dateNum)")
        let date = Date(timeIntervalSince1970: TimeInterval(dateNum))
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT") //Set timezone that you want
        dateFormatter.locale = NSLocale.current
        dateFormatter.dateFormat = formatString //Specify your format that you want
        return dateFormatter.string(from: date)
    }
    
    func updateLabels(result:NSDictionary){
        //using serial queue so I can get the data this first block of code
        DispatchQueue.main.async { [weak self] in
            //update UI
            //self!.onlineImageView.image = UIImage(data: data!)
            //print("These are supposet to be set: \(String(describing: self?.locationStr)), \(String(describing: self?.tempStr)) & \(String(describing: self?.wcodeStr))")
            let celcius = "°C"
            let locDict = result["location"] as! NSDictionary
            let city = locDict["city"] as! String
            let region = locDict["region"] as! String
            let country = locDict["country"] as! String
            
            self?.locationLabel.text = String("\(city), \(region), \(country)")
            let co = result["current_observation"] as! NSDictionary
            let condition = co["condition"] as! NSDictionary
            
            self?.tempLabel.text = String("\(condition["temperature"] as! Int)\(celcius)")
            let code = condition["code"] as! Int
            let wicon = self?.wc.iconDict[code]
            self?.iconLabel.text = wicon
            self?.wtextLabel.text = condition["text"] as? String
        }
    }
    
    
    
    //functions for Navigation menu icons
    // add
    // saved
    @objc func addTapped(sender: AnyObject){
        //print("add was pressed")
        performSegue(withIdentifier: "detailsToAdd", sender: nil)
        
    }
    
    @objc func savedTapped(sender: AnyObject){
        //print("favourites was pressed")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //nav bar button
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))

        
        // Weather by location as json and in celsius/metric units.
        weatherGetter.delegate = self
        
        /**
         Sample Data!!! it's working! single location (celcius ,json)
         
         {"location":{"woeid":4118,"city":"Toronto","region":" ON","country":"Canada","lat":43.64856,"long":-79.385368,"timezone_id":"America/Toronto"},"current_observation":{"wind":{"chill":3,"direction":85,"speed":17.0},"atmosphere":{"humidity":63,"visibility":16.1,"pressure":1015.0,"rising":0},"astronomy":{"sunrise":"6:01 am","sunset":"8:28 pm"},"condition":{"text":"Partly Cloudy","code":30,"temperature":7},"pubDate":1557349200},"forecasts":[{"day":"Wed","date":1557288000,"low":5,"high":7,"text":"Partly Cloudy","code":30},{"day":"Thu","date":1557374400,"low":5,"high":12,"text":"Rain","code":12},{"day":"Fri","date":1557460800,"low":5,"high":13,"text":"Rain","code":12},{"day":"Sat","date":1557547200,"low":3,"high":8,"text":"Mostly Cloudy","code":28},{"day":"Sun","date":1557633600,"low":5,"high":7,"text":"Scattered Showers","code":39},{"day":"Mon","date":1557720000,"low":6,"high":6,"text":"Scattered Showers","code":39},{"day":"Tue","date":1557806400,"low":5,"high":12,"text":"Scattered Showers","code":39},{"day":"Wed","date":1557892800,"low":9,"high":12,"text":"Scattered Showers","code":39},{"day":"Thu","date":1557979200,"low":6,"high":11,"text":"Partly Cloudy","code":30},{"day":"Fri","date":1558065600,"low":6,"high":10,"text":"Scattered Showers","code":39}]}
         **/
        
        
        /*******
         ************the code below should be in a protocol
 *********/
        
        
        //need to dispatch a global queue to do the network call
        //lets make this a serial queue because we need the data for this in our tableview functions
    
        self.weatherGetter.getWeatherValue(wlocation: self.passedLocation)
            
            //assuming json is good to go at this point!
            //validated on https://jsonlint.com/
        
        
                        //Should have enough data for current time's weather
                        //now time for the days forcast list
                        
        
            //print(url)
            
        
        
    }
    
}
