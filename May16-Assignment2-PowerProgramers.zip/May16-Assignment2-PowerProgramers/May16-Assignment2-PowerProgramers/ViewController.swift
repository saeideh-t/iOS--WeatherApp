//
//  ViewController.swift
//  May16-Assignment2-PowerProgramers
//
//  Created by user151804 on 5/13/19.
//  Copyright © 2019 Seneca College. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

