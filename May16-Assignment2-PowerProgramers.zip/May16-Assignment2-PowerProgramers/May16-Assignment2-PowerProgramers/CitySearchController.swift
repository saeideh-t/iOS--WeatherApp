//
//  CitySearchController.swift
//  May16-Assignment2-PowerProgramers
//
//  Created by user151804 on 5/13/19.
//  Copyright © 2019 Seneca College. All rights reserved.
//

import UIKit

class CitySearchController: UITableViewController, UISearchBarDelegate, FetchLocationDelegate, FetchWeatherDelegate {
    
    
    @IBOutlet var locationsTableView: UITableView!
    var locationResults = Array<NSDictionary>()
    var weatherResult = NSDictionary()
    var locationGetter = FetchLocation()
    var weatherGetter = FetchWeather()
    var yahooable = Array<NSDictionary>()
    var tvindex:Int = 0;
    
    //NavigationBar menu item function
    @objc func savedTapped(sender: AnyObject){
        //print("favourites was pressed")
        performSegue(withIdentifier: "addToSaved", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addToSavedViaCell" {
            if let destinationVC = segue.destination as? STVController {
                //add selected cell to database
                let indexPath = tableView.indexPathForSelectedRow
                let cell = tableView.cellForRow(at: indexPath!)
                let sendToDB = cell!.textLabel!.text!
                destinationVC.add(name: sendToDB)
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //nav bar button
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .bookmarks, target: self, action: #selector(savedTapped))

        
        
        locationGetter.delegate = self
        weatherGetter.delegate = self
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    func weatherDetailsResult(value: NSDictionary) {
        weatherResult = value
        //if a location was found by YahooAPI
        let rloc = value["location"] as! NSDictionary //raw with extra data
        let loc = [
            "city": rloc["city"] as? String ?? "n/a",
            "region": rloc["region"] as? String ?? "n/a" ,
            "country": rloc["country"] as? String ?? "n/a"
        ] as NSDictionary //stripped to just {city, region,county}
        //all rloc items are unique but may share {city, region,county} so need to filter
        if loc.count != 0 {
            if loc["city"] as! String != "n/a" && !yahooable.contains(loc as NSDictionary) {
                
                //add to yahooable
                yahooable.append(loc)
                locationsTableView.reloadData()
                // filtering data from GeoNames to only include what Yahoo Weather API can use
            }
        }
    }
    
    func resultCompletedWithValues(value: Array<NSDictionary>) {
        locationResults = value
        
        yahooable = Array<NSDictionary>()
        let tempArr = value
        tempArr.forEach{
            // from Dictionary from json results
            let city = $0["name"] as? String ?? " "
            let province = $0["adminName1"] as? String ?? " "
            let country = $0["countryName"] as? String ?? " "
            let nameStr = String("\(city), \(province), \(country)")
          weatherGetter.getWeatherValue(wlocation: nameStr)
        }
        locationsTableView.reloadData()
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //if I type too quick I get wonky results with more cities but I think they are all yahooable.
        DispatchQueue.global().async {
        //hack for for space character
        let newStr = searchText.replacingOccurrences(of: " ", with: "%20")
        self.locationGetter.getLocationsValue(searchStr: newStr)
        }
        //a hack for fast typing?
        
        
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //nuber of cities in our results
        return yahooable.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cityResult", for: indexPath)

        // from Dictionary from json results
        let city = yahooable[indexPath.row]["city"] as? String ?? " "
        let province = yahooable[indexPath.row]["region"] as? String ?? " "
        let country = yahooable[indexPath.row]["country"] as? String ?? " "
        let cellStr = String("\(city), \(province), \(country)")
        //print(cellStr)
        cell.textLabel?.text = cellStr
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //ok should be ok to send to next screen to save in core data
        let cell = tableView.cellForRow(at: indexPath)
        let name = cell?.textLabel!.text!
        let alert = UIAlertController(title: "Location Saved", message: String("\(name!) is now saved!"), preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok!", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
