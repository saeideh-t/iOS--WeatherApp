//
//  File.swift
//  May16-Assignment2-PowerProgramers
//
//  Created by user151804 on 5/13/19.
//  Copyright © 2019 Seneca College. All rights reserved.
//
//  Code Modified from Yahoo Developer Network
//
//  OAuthSwift used for authentication to Yahoo services
//  Original Yahoo Code - Copyright 2019 Oath Inc. Licensed under the terms of the zLib license see https://opensource.org/licenses/Zlib for terms.
//

import UIKit
/*
 See https://github.com/OAuthSwift/OAuthSwift for information on
 including this OAuth library in your project.
 Downloaded from github and dragged the OAuthSwift.xcodeproj file into project
 ***Needed to authenticate with google***
 */
import OAuthSwift

class YWeatherAPI {
    
    
    fileprivate struct YWeatherAPIClientCredentials {
        var appId = ""
        var clientId = ""
        var clientSecret = ""
    }
    
    enum YWeatherAPIResponseType:String {
        case json = "json"
        case xml = "xml"
    }
    
    enum YWeatherAPIUnitType:String {
        case imperial = "f"
        case metric = "c"
    }
    
    
    
    
    
    
    class YWeatherAPI {
        // Configure the following with your values.
        //Developer ID, ***please change to personal developer ID if sharing code outside of YWCA Mobile Development Program 2019**
        private let credentials = YWeatherAPIClientCredentials(appId: "5loRSD7a", clientId: "dj0yJmk9cnVleXhyZnVvU3RtJnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PWMz", clientSecret: "cfd2dc874e95b2b5427ea6f45ba5bad4af7a9a4a")
        
        private let url:String = "https://weather-ydn-yql.media.yahoo.com/forecastrss"
        private let oauth:OAuth1Swift?
        
        //no need to actually instantiate if it's a static public variable
        public static let shared = YWeatherAPI()
        
        
        //https://erikflowers.github.io/weather-icons/
        //https://erikflowers.github.io/weather-icons/api-list.html
        //unicode for weather icon font
        //only shows daytime version, no matter the time of day
        public let iconDict:[Int:String] = [
            0:"\u{f056}", //tornado
            1:"\u{f00e}", //day-storm-showers
            2:"\u{f073}", //hurricane
            3:"\u{f01e}", // severe thunderstorms
            4:"\u{f01d}", //thunderstorms
            5:"\u{f017}", //rain-mix
            6:"\u{f017}", //rain-mix
            7:"\u{f056}", //rain-mix
            8:"\u{f015}", //hail
            9:"\u{f01a}", //showers
            10:"\u{f015}", //hail
            11:"\u{f01a}", //showers
            12:"\u{f01a}", //showers
            13:"\u{f01b}", //snow
            14:"\u{f00a}", //day-snow
            15:"\u{f064}", //snow-wind
            16:"\u{f01b}", //snow
            17:"\u{f015}", //hail
            18:"\u{f017}", //rain-mix
            19:"\u{f063}", //dust
            20:"\u{f014}", //fog
            21:"\u{f021}", //windy
            22:"\u{f062}", //smoke
            23:"\u{f050}", //strong-wind
            24:"\u{f050}", //strong-wind
            25:"\u{f076}", //snowflake-cold
            26:"\u{f013}", //cloudy
            27:"\u{f031}", //night-cloudy
            28:"\u{f002}", //day-cloudy
            29:"\u{f031}", //night-cloudy
            30:"\u{f002}", //day-cloudy
            31:"\u{f02e}", //night-clear
            32:"\u{f00d}", //day-sunny
            33:"\u{f083}", //night-partly-cloudy
            34:"\u{f00c}", //day-sunny-overcast
            35:"\u{f017}", //rain-mix
            36:"\u{f072}", //hot
            37:"\u{f00e}", //day-storm-showers
            38:"\u{f00e}", //day-storm-showers
            39:"\u{f00e}", //day-storm-showers
            40:"\u{f01a}", //showers
            41:"\u{f064}", //snow-wind
            42:"\u{f01b}", //snow
            43:"\u{f064}", //snow-wind
            44:"\u{f00c}", //day-sunny-overcast
            45:"\u{f00e}", //day-storm-showers
            46:"\u{f01b}", //snow
            47:"\u{f00e}", //day-storm-showers
            3200:"\u{f077}" //stars - N/A
        ]
        
        private init() {
            self.oauth = OAuth1Swift(consumerKey: self.credentials.clientId, consumerSecret: self.credentials.clientSecret)
        }
        
        private var headers:[String:String] {
            return [
                "X-Yahoo-App-Id": self.credentials.appId
            ]
        }
        
        //This will be the one we we call most likely unless we map location to woeid or lat,long in database
        
        /// Requests weather data by location name.
        ///
        /// - Parameters:
        ///   - location: the name of the location, i.e. sunnyvale,ca
        ///   - failure: failure callback
        ///   - success: success callback
        ///   - responseFormat: .xml or .json. default is .json.
        ///   - unit: metric or imperial units. default = .metric
        
        public func weather(location:String, failure: @escaping (_ error: OAuthSwiftError) -> Void, success: @escaping (_ response: OAuthSwiftResponse) -> Void, responseFormat:YWeatherAPIResponseType = .json, unit:YWeatherAPIUnitType = .metric) {
            self.makeRequest(parameters: ["location":location, "format":responseFormat.rawValue, "u":unit.rawValue], failure: failure, success: success)
        }
        
        
        /// Requests weather data by woeid (Where on Earth ID)
        ///
        /// - Parameters:
        ///   - woeid: The location's woeid
        ///   - failure: failure callback
        ///   - success: success callback
        ///   - responseFormat: .xml or .json. default is .json.
        ///   - unit: metric or imperial units. default = .metric
        
        public func weather(woeid:String, failure: @escaping (_ error: OAuthSwiftError) -> Void, success: @escaping (_ response: OAuthSwiftResponse) -> Void, responseFormat:YWeatherAPIResponseType = .json, unit:YWeatherAPIUnitType = .metric) {
            self.makeRequest(parameters: ["woeid":woeid, "format":responseFormat.rawValue, "u":unit.rawValue], failure: failure, success: success)
        }
        
        
        /// Requests weather data by latitude and longitude
        ///
        /// - Parameters:
        ///   - lat: latitude
        ///   - lon: longiture
        ///   - failure: failure callback
        ///   - success: success callback
        ///   - responseFormat: .xml or .json. default is .json.
        ///   - unit: metric or imperial units. default = .metric
        public func weather(lat:String, lon:String, failure: @escaping (_ error: OAuthSwiftError) -> Void, success: @escaping (_ response: OAuthSwiftResponse) -> Void, responseFormat:YWeatherAPIResponseType = .json, unit:YWeatherAPIUnitType = .metric) {
            self.makeRequest(parameters: ["lat":lat, "lon":lon, "format":responseFormat.rawValue, "u":unit.rawValue], failure: failure, success: success)
        }
        
        
        /// Performs the API request with the OAuthSwift client
        ///
        /// - Parameters:
        ///   - parameters: Any URL parameters to pass to the endpoint.
        ///   - failure: failure callback
        ///   - success: success callback
        private func makeRequest(parameters:[String:String], failure: @escaping (_ error: OAuthSwiftError) -> Void, success: @escaping (_ response: OAuthSwiftResponse) -> Void) {
            self.oauth?.client.request(self.url, method: .GET, parameters: parameters, headers: self.headers, body: nil, checkTokenExpiration: true, success: success, failure: failure)
        }
        
    }
    
}
