//
//  File.swift
//  May16-Assignment2-PowerProgramers
//
//  Created by user151804 on 5/13/19.
//  Copyright © 2019 Seneca College. All rights reserved.
//

import Foundation

protocol FetchWeatherDelegate {
    func weatherDetailsResult(value : NSDictionary)
}

class FetchWeather{
    var delegate : FetchWeatherDelegate?
    
    //using the YahooWeatherAPI to connect to server
    
    func getWeatherValue(wlocation : String)  {
        
        var result : NSDictionary = NSDictionary()
        let wc = YWeatherAPI.YWeatherAPI.shared //Yahoo Weather API
        wc.weather(location: wlocation, failure: { (error) in
            print(error.localizedDescription)
        }, success: { (response) in
            //assuming json is good to go at this point!
            //validated on https://jsonlint.com/
            //serialzise json
            
            let data = Data(response.string!.utf8)
            do {
                // make sure this JSON is in the format we expect
                if let json = try JSONSerialization.jsonObject(with: data, options:.allowFragments) as? NSDictionary {
                    
                    result = json
                    
                    DispatchQueue.main.async { [weak self] in
                        //assign any UI?
                        self!.delegate?.weatherDetailsResult(value : result)
                    }
                    
                }
            } catch let error as NSError {
                print("Failed to load: \(error.localizedDescription)")
            }
        }, responseFormat: .json, unit: .metric)
        
        
    
        
        
    }
    
}
