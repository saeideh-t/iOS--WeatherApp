//
//  FetchLocations.swift
//  May16-Assignment2-PowerProgramers
//
//  Created by user151804 on 5/13/19.
//  Copyright © 2019 Seneca College. All rights reserved.
//

import Foundation

protocol FetchLocationDelegate {
    func resultCompletedWithValues(value : Array<NSDictionary>)
}


class FetchLocation {
    var delegate : FetchLocationDelegate?
    
    func getData(urlObject : URL , completionHandler : @escaping (Data)->())  {
        //step 3
        let config = URLSessionConfiguration.default
        let session = URLSession.init(configuration: config)
        
        let task = session.dataTask(with: urlObject) { (data, response, error) in
            if let myData = data {
                //step 4
                completionHandler(myData)
            }
            else {
                print("error in downloadeing \(String(describing: error))" )
            }
        }
        task.resume()
        
    }
    
    
    func getLocationsValue(searchStr : String)  {
        
        
        //step 2
        //api.geonames.com for names service, url added to plist as exception
        let urlString =  "http://api.geonames.org/searchJSON?q=\(searchStr)&maxRows=10&username=fayola"
        
        
        var results : Array<NSDictionary> = []
        let urlObject : URL = URL(string: urlString)!
        getData(urlObject: urlObject) { (data) in
            do{
                
                // step 5
                let json = try JSONSerialization.jsonObject(with: data, options: []) as!  NSDictionary
                //return a result or empty array
                results = json.value(forKey: "geonames") as! Array<NSDictionary>? ?? []
                DispatchQueue.main.async {
                    self.delegate?.resultCompletedWithValues(value: results)
                    
                }
                
                
            } catch let error as NSError {
                print("Failed to load: \(error.localizedDescription)")
            }
            
            
        }
        
        
    }
}
