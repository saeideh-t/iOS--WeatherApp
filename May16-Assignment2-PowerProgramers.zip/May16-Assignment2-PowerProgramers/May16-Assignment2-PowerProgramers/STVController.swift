//
//  STVController.swift
//  May16-Assignment2-PowerProgramers
//
//  Created by user151804 on 5/14/19.
//  Copyright © 2019 Seneca College. All rights reserved.
//

import UIKit
import CoreData

class STVController: UITableViewController, UISearchBarDelegate, NSFetchedResultsControllerDelegate {
    
    
    
    
    var places = [Place]() //might not need this, using Fetch Controller
    
    var passingLocation = "banff, ab"
    
    lazy var appDelegate = UIApplication.shared.delegate as! AppDelegate  //need this for the NSManagedObjectContext for NSFetchedResultController
    
    lazy var fetchResult : NSFetchedResultsController<Place> = {
        let FetchReq  : NSFetchRequest<Place> = Place.fetchRequest()
       let sort = NSSortDescriptor(key: "name", ascending: true)
        FetchReq.propertiesToFetch = ["name"]
        FetchReq.returnsDistinctResults = true   // don't show duplicates (not working!)
        FetchReq.sortDescriptors = [sort]
        let fetchResult = NSFetchedResultsController(fetchRequest: FetchReq, managedObjectContext: appDelegate.persistentContainer.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchResult.delegate = self;
        return fetchResult
    }()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "savedToDetails" {
            //print("savedToDetails segue")
            if let destinationVC = segue.destination as? WTVController {
                    destinationVC.passedLocation = passingLocation
            }
        }
    }
    
    
    
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        var myPredicate : NSPredicate? = nil
//        if (searchText.count > 0){
//            myPredicate = NSPredicate(format: "name CONTAINS %@", searchText)
//        }
//        fetchResult.fetchRequest.predicate = myPredicate
//        doFetch()
//        tableView.reloadData()
//    }
    
    //functions for Navigation menu icons
    // add
    // saved
    @objc func addTapped(sender: AnyObject){
        //print("add was pressed")
        performSegue(withIdentifier: "savedToAdd", sender: nil)
        
    }
    
    override func viewDidLoad() {
        //doesn't seem to be loading
        super.viewDidLoad()
        
        //nav bar button
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))

        
        //fetch data
        doFetch()
        let count = fetchResult.fetchedObjects?.count ?? 0
        //add Toronto to our database if it's empty
        //print("amount in  database \(count)")
        if count == 0 {
            //print("adding Toronto")
            add(name: "Toronto, ON, Canada")
            doFetch()
        }
        //tableView.reloadData() //using controller - no need to reload
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    func add(name:String) {
        let fetchReq  = NSFetchRequest<Place>(entityName: "Place")
        fetchReq.predicate = NSPredicate(format: "title = %@", name)
        
       
       // let fResult = NSFetchRequestResult(fetchRequest: fetchReq, managedObjectContext: appDelegate.persistentContainer.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        var count = 0
//        do{
//            let places = try
//                //use a fetch not associated with the controller
//                appDelegate.persistentContainer.viewContext.fetch(fetchReq)
//
//            count = places.count //if 0 then insert
//            if count != 0 {
//                }
//
//        }catch{
//            //tell user reinstall
//        }
        //issues trying to show alert when adding during a segue or when view controller is not in view
        /**
  Warning: Attempt to present <UIAlertController: 0x7fc41f005600> on <May16_Assignment2_PowerProgramers.STVController: 0x7fc420c12330> whose view is not in the window hierarchy!
 **/
        let p = NSEntityDescription.insertNewObject(forEntityName: "Place", into: appDelegate.persistentContainer.viewContext) as! Place
        p.name = name
        appDelegate.saveContext();
        
        
    }
    
    func doFetch() {
        do{
            try fetchResult.performFetch()
        }catch{
            //tell user reinstall
        }
    }
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fetchResult.fetchedObjects?.count ?? 0
    }

//    override func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
//        return "Delete Me!" // or trash icon maybe
//    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let deleteButton = UITableViewRowAction(style: .default, title: "Delete Me!") { (action, indexPath) in
            self.tableView.dataSource?.tableView!(self.tableView, commit: .delete, forRowAt: indexPath)
            return
        }
        deleteButton.backgroundColor = UIColor.black
        return [deleteButton]
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let objectToRemove =  fetchResult.object(at: indexPath)
            appDelegate.persistentContainer.viewContext.delete(objectToRemove)
            appDelegate.saveContext()
        }
    }
    
//    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        return  (fetchResult.sections![section]).name
//    }
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "placeCell")
        let p =  fetchResult.object(at: indexPath)
        //cell?.textLabel?.text = String("\(p.city!), \(p.region!), \(p.country!)")
        cell?.textLabel?.text = p.name
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //change passingLocation
        //print(passingLocation)
        passingLocation = tableView.cellForRow(at: indexPath)!.textLabel!.text!
        //segue to WTVController
        performSegue(withIdentifier: "savedToDetails", sender: nil)
        
        
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        switch type {
        case .insert:
            break
        case .delete:
            tableView.deleteSections(IndexSet(integer: sectionIndex), with: .fade)
        case .move:
            break
        case .update:
            break
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            tableView.insertRows(at: [newIndexPath!], with: .fade)
        case .delete:
            tableView.deleteRows(at: [indexPath!], with: .fade)
        case .update:
            tableView.reloadRows(at: [indexPath!], with: .fade)
        case .move:
            tableView.moveRow(at: indexPath!, to: newIndexPath!)
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
    
}
